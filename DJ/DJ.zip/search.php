<?php
/**
 * Template Name: Search
 */
?>

<?php
 /**
 * The template for displaying Search Results pages.
 *http://www.google.com/cse
 * @package WordPress
 * @subpackage DJ
 * @since DJ 0.1
 */

get_header(); ?>

<div id="cse">Loading</div>
<script src="https://www.google.com/jsapi" type="text/javascript"></script>
<script type="text/javascript"> 
  google.load('search', '1', {language : 'zh-CN', style : google.loader.themes.SHINY});
  google.setOnLoadCallback(function() {
    var customSearchOptions = {};
  
    var imageSearchOptions = {};
    imageSearchOptions['layout'] = google.search.ImageSearch.LAYOUT_POPUP;
    customSearchOptions['enableImageSearch'] = true;
    customSearchOptions['imageSearchOptions'] = imageSearchOptions;
  
    var customSearchControl = new google.search.CustomSearchControl(
      '010809034132572699668:69nzlkcq1w4', customSearchOptions);

    customSearchControl.setResultSetSize(google.search.Search.FILTERED_CSE_RESULTSET);
    var options = new google.search.DrawOptions();
    options.setAutoComplete(true);
    customSearchControl.draw('cse', options);
  }, true);
</script>


<?php get_footer(); ?>
