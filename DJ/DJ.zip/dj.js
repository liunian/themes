/*
@version 0.1
@author deng 
*/
jQuery(document).ready(function($){
	
	$('.post-title > a, .more-link').click(function(){
		var text = $(this).text();
		$(this).text("正在努力加载…");
		window.location = $(this).attr('href');
		$(this).delay(3000).fadeOut('slow',function(){
			$(this).text(text);
			})
			.fadeIn('slow');	
	});
	
	$('#submit').val($('#submit').val() + '(Ctrl + Enter)');
	
	$('#comment').keydown(function(e){
		if (!$('#submit').attr('disabled') && e.ctrlKey && e.keyCode==13) {
			$('#commentform').submit();
		}
	});	
});
